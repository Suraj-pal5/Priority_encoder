0 0 dataAuditErrors
467 0 SI g45inda connectionErrors
468 0 SI g45inda spacingErrors
469 0 SI g45inda innerDiameterErrors
470 0 SI g45inda widthErrors
484 0 ptap_StampErrorFloat
485 0 ptap_StampErrorMult
486 0 ptap_StampErrorConnect
491 0 psubstrate_StampErrorFloat
492 0 psubstrate_StampErrorMult
493 0 psubstrate_StampErrorConnect
498 0 ntap_StampErrorFloat
499 0 ntap_StampErrorMult
500 0 ntap_StampErrorConnect
505 0 nwell_conn_StampErrorFloat
506 0 nwell_conn_StampErrorMult
507 0 nwell_conn_StampErrorConnect
512 0 nb_tap_StampErrorFloat
513 0 nb_tap_StampErrorMult
514 0 nb_tap_StampErrorConnect
519 0 Nburied_StampErrorFloat
520 0 Nburied_StampErrorMult
521 0 Nburied_StampErrorConnect
526 0 ptap_StampErrorFloat
527 0 ptap_StampErrorMult
528 0 ptap_StampErrorConnect
533 0 psubstrate_StampErrorFloat
534 0 psubstrate_StampErrorMult
535 0 psubstrate_StampErrorConnect
540 0 ntap_StampErrorFloat
541 0 ntap_StampErrorMult
542 0 ntap_StampErrorConnect
547 0 nwell_conn_StampErrorFloat
548 0 nwell_conn_StampErrorMult
549 0 nwell_conn_StampErrorConnect
554 0 nb_tap_StampErrorFloat
555 0 nb_tap_StampErrorMult
556 0 nb_tap_StampErrorConnect
561 0 Nburied_StampErrorFloat
562 0 Nburied_StampErrorMult
563 0 Nburied_StampErrorConnect
579 0 all malformed SI g45inda
2653 0 malformed device RECOG_NEW_T?466
2654 0 malformed device _nmos1v
2655 0 malformed device _nmos1v_hvt
2656 0 malformed device _nmos1v_lvt
2657 0 malformed device _nmos_12_native
2658 0 malformed device _nmos_25
2659 0 malformed device _nmos_25_native
2660 0 malformed device _nmoscap1v
2661 0 malformed device _nmoscap2v
2662 0 malformed device _pmos1v
2663 0 malformed device _pmos1v_hvt
2664 0 malformed device _pmos1v_lvt
2665 0 malformed device _pmos2v
2666 0 malformed device _pmoscap1v
2667 0 malformed device _pmoscap2v
2668 0 malformed device _resm1
2669 0 malformed device _resm2
2670 0 malformed device _resm3
2671 0 malformed device _resm4
2672 0 malformed device _resm5
2673 0 malformed device _resm6
2674 0 malformed device _resm7
2675 0 malformed device _resm8
2676 0 malformed device _resm9
2677 0 malformed device _resm10
2678 0 malformed device _resm11
2679 0 malformed device _ressndiff
2680 0 malformed device _resnsndiff
2681 0 malformed device _ressnpoly
2682 0 malformed device _ressnpoly_nw
2683 0 malformed device _resnsnpoly
2684 0 malformed device _resnsnpoly_nw
2685 0 malformed device _resspdiff
2686 0 malformed device _resnspdiff
2687 0 malformed device _ressppoly
2688 0 malformed device _ressppoly_nw
2689 0 malformed device _resnsppoly
2690 0 malformed device _resnsppoly_nw
2691 0 malformed device _resnwsti
2692 0 malformed device _resnwoxide
2693 0 malformed device _ndio
2694 0 malformed device _ndio_lvt
2695 0 malformed device _ndio_hvt
2696 0 malformed device _ndio_nvt
2697 0 malformed device _ndio_2v
2698 0 malformed device _ndio_2v_nvt
2699 0 malformed device _pdio
2700 0 malformed device _pdio_lvt
2701 0 malformed device _pdio_hvt
2702 0 malformed device _pdio_2v
2703 0 malformed device _vpnp2
2704 0 malformed device _vpnp5
2705 0 malformed device _vpnp10
2706 0 malformed device _npn2
2707 0 malformed device _npn5
2708 0 malformed device _npn10
2709 0 malformed device _mimcap
2710 0 malformed device _ind_s
3037 0 unstable device for _ind_s_Device_58
3038 0 unpreserved device _ind_s_Device_58
3039 0 unstable device for _mimcap_CAP_57
3040 0 unpreserved device _mimcap_CAP_57
3041 0 unstable device for _npn10_BJT_56
3042 0 unpreserved device _npn10_BJT_56
3043 0 unstable device for _npn5_BJT_55
3044 0 unpreserved device _npn5_BJT_55
3045 0 unstable device for _npn2_BJT_54
3046 0 unpreserved device _npn2_BJT_54
3047 0 unstable device for _vpnp10_BJT_53
3048 0 unpreserved device _vpnp10_BJT_53
3049 0 unstable device for _vpnp5_BJT_52
3050 0 unpreserved device _vpnp5_BJT_52
3051 0 unstable device for _vpnp2_BJT_51
3052 0 unpreserved device _vpnp2_BJT_51
3053 0 unstable device for _pdio_2v_DIODE_50
3054 0 unpreserved device _pdio_2v_DIODE_50
3055 0 unstable device for _pdio_hvt_DIODE_49
3056 0 unpreserved device _pdio_hvt_DIODE_49
3057 0 unstable device for _pdio_lvt_DIODE_48
3058 0 unpreserved device _pdio_lvt_DIODE_48
3059 0 unstable device for _pdio_DIODE_47
3060 0 unpreserved device _pdio_DIODE_47
3061 0 unstable device for _ndio_2v_nvt_DIODE_46
3062 0 unpreserved device _ndio_2v_nvt_DIODE_46
3063 0 unstable device for _ndio_2v_DIODE_45
3064 0 unpreserved device _ndio_2v_DIODE_45
3065 0 unstable device for _ndio_nvt_DIODE_44
3066 0 unpreserved device _ndio_nvt_DIODE_44
3067 0 unstable device for _ndio_hvt_DIODE_43
3068 0 unpreserved device _ndio_hvt_DIODE_43
3069 0 unstable device for _ndio_lvt_DIODE_42
3070 0 unpreserved device _ndio_lvt_DIODE_42
3071 0 unstable device for _ndio_DIODE_41
3072 0 unpreserved device _ndio_DIODE_41
3073 0 unstable device for _resnwoxide_RES_40
3074 0 unpreserved device _resnwoxide_RES_40
3075 0 unstable device for _resnwsti_RES_39
3076 0 unpreserved device _resnwsti_RES_39
3077 0 unstable device for _resnsppoly_nw_RES_38
3078 0 unpreserved device _resnsppoly_nw_RES_38
3079 0 unstable device for _resnsppoly_RES_37
3080 0 unpreserved device _resnsppoly_RES_37
3081 0 unstable device for _ressppoly_nw_RES_36
3082 0 unpreserved device _ressppoly_nw_RES_36
3083 0 unstable device for _ressppoly_RES_35
3084 0 unpreserved device _ressppoly_RES_35
3085 0 unstable device for _resnspdiff_RES_34
3086 0 unpreserved device _resnspdiff_RES_34
3087 0 unstable device for _resspdiff_RES_33
3088 0 unpreserved device _resspdiff_RES_33
3089 0 unstable device for _resnsnpoly_nw_RES_32
3090 0 unpreserved device _resnsnpoly_nw_RES_32
3091 0 unstable device for _resnsnpoly_RES_31
3092 0 unpreserved device _resnsnpoly_RES_31
3093 0 unstable device for _ressnpoly_nw_RES_30
3094 0 unpreserved device _ressnpoly_nw_RES_30
3095 0 unstable device for _ressnpoly_RES_29
3096 0 unpreserved device _ressnpoly_RES_29
3097 0 unstable device for _resnsndiff_RES_28
3098 0 unpreserved device _resnsndiff_RES_28
3099 0 unstable device for _ressndiff_RES_27
3100 0 unpreserved device _ressndiff_RES_27
3101 0 unstable device for _resm11_RES_26
3102 0 unpreserved device _resm11_RES_26
3103 0 unstable device for _resm10_RES_25
3104 0 unpreserved device _resm10_RES_25
3105 0 unstable device for _resm9_RES_24
3106 0 unpreserved device _resm9_RES_24
3107 0 unstable device for _resm8_RES_23
3108 0 unpreserved device _resm8_RES_23
3109 0 unstable device for _resm7_RES_22
3110 0 unpreserved device _resm7_RES_22
3111 0 unstable device for _resm6_RES_21
3112 0 unpreserved device _resm6_RES_21
3113 0 unstable device for _resm5_RES_20
3114 0 unpreserved device _resm5_RES_20
3115 0 unstable device for _resm4_RES_19
3116 0 unpreserved device _resm4_RES_19
3117 0 unstable device for _resm3_RES_18
3118 0 unpreserved device _resm3_RES_18
3119 0 unstable device for _resm2_RES_17
3120 0 unpreserved device _resm2_RES_17
3121 0 unstable device for _resm1_RES_16
3122 0 unpreserved device _resm1_RES_16
3123 0 unstable device for _pmoscap2v_MOS_15
3124 0 unpreserved device _pmoscap2v_MOS_15
3125 0 unstable device for _pmoscap1v_MOS_14
3126 0 unpreserved device _pmoscap1v_MOS_14
3127 0 unstable device for _pmos2v_MOS_13
3128 0 unpreserved device _pmos2v_MOS_13
3129 0 unstable device for _pmos1v_lvt_MOS_12
3130 0 unpreserved device _pmos1v_lvt_MOS_12
3131 0 unstable device for _pmos1v_hvt_MOS_11
3132 0 unpreserved device _pmos1v_hvt_MOS_11
3133 0 unstable device for _pmos1v_MOS_10
3134 0 unpreserved device _pmos1v_MOS_10
3135 0 unstable device for _nmoscap2v_MOS_9
3136 0 unpreserved device _nmoscap2v_MOS_9
3137 0 unstable device for _nmoscap1v_MOS_8
3138 0 unpreserved device _nmoscap1v_MOS_8
3139 0 unstable device for _nmos_25_native_MOS_7
3140 0 unpreserved device _nmos_25_native_MOS_7
3141 0 unstable device for _nmos_25_MOS_6
3142 0 unpreserved device _nmos_25_MOS_6
3143 0 unstable device for _nmos_12_native_MOS_5
3144 0 unpreserved device _nmos_12_native_MOS_5
3145 0 unstable device for _nmos1v_lvt_MOS_4
3146 0 unpreserved device _nmos1v_lvt_MOS_4
3147 0 unstable device for _nmos1v_hvt_MOS_3
3148 0 unpreserved device _nmos1v_hvt_MOS_3
3149 0 unstable device for _nmos1v_MOS_2
3150 0 unpreserved device _nmos1v_MOS_2
3151 0 unstable device for DEVICE_LAYER_RECOG_NEW_T?466_SI_1
3152 0 unpreserved device DEVICE_LAYER_RECOG_NEW_T?466_SI_1
