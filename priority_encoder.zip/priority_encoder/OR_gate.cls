*******************************************************************************
****** inverter schematic prio_encode  <vs>  inverter layout prio_encode
*******************************************************************************

Filter/Reduce statistics only. Network matching was OK.
                                                                                                                                                                   
Pre-expand Statistics                      
======================                          Original       
Cell/Device                               schematic  layout
(g45n1svt) MOS                                    1       1
(g45p1svt) MOS                                    1       1
                                             ------  ------
Total                                             2       2

Reduce Statistics
=================                               Original             Reduced
Cell/Device                               schematic  layout   schematic  layout
(g45n1svt) MOS                                    1       1           1       1
(g45p1svt) MOS                                    1       1           1       1
                                             ------  ------      ------  ------
Total                                             2       2           2       2

*******************************************************************************
****** OR_gate schematic prio_encode  <vs>  OR_gate layout prio_encode
*******************************************************************************

Filter/Reduce statistics only. Network matching was OK.
                                                                                                                                                                   
Pre-expand Statistics                      
======================                          Original       
Cell/Device                               schematic  layout
(inverter schematic prio_encode, inverter) Cell           1       1
(g45n1svt) MOS                                    3       3
(g45p1svt) MOS                                    1       1
                                             ------  ------
Total                                             5       5

Reduce Statistics
=================                               Original             Reduced
Cell/Device                               schematic  layout   schematic  layout
(inverter) Cell                                   1       1           1       1
(g45n1svt) MOS                                    3       3           0       0
(g45p1svt) MOS                                    1       1           1       1
(g45n1svt:ParMos2#1) MosBlk                       -       -           1       1
(g45n1svt:SerMos3#1) MosBlk                       -       -           1       1
                                             ------  ------      ------  ------
Total                                             5       5           4       4

Schematic and Layout Match
