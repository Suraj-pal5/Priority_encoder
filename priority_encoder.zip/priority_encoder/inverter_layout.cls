*******************************************************************************
****** inverter schematic prio_encode  <vs>  inverter_layout layout prio_encode
*******************************************************************************

Filter/Reduce statistics only. Network matching was OK.
                                                                                                                                                                   
Pre-expand Statistics                      
======================                          Original       
Cell/Device                               schematic  layout
(g45n1svt) MOS                                    1       1
(g45p1svt) MOS                                    1       1
                                             ------  ------
Total                                             2       2

Reduce Statistics
=================                               Original             Reduced
Cell/Device                               schematic  layout   schematic  layout
(g45n1svt) MOS                                    1       1           1       1
(g45p1svt) MOS                                    1       1           1       1
                                             ------  ------      ------  ------
Total                                             2       2           2       2

Schematic and Layout Match
